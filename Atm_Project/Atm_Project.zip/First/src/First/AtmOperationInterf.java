package First;

public interface AtmOperationInterf {
	public void viewBalance();
	public void withdrawAmount(double withdrawAmount);
	public void depositeAmount(double depositAmount);
	public void viewMiniStatement();
	
	

}
