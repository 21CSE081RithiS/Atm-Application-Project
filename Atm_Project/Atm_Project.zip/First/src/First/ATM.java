package First;

public class ATM {


private double balance;
private double dopositeAmount;
private double withdrawAmount;



//default constructor
public ATM() {
	
}
//getter setter

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

public double getDopositeAmount() {
	return dopositeAmount;
}

public void setDopositeAmount(double dopositeAmount) {
	this.dopositeAmount = dopositeAmount;
}

public double getWithdrawAmount() {
	return withdrawAmount;
}

public void setWithdrawAmount(double withdrawAmount) {
	this.withdrawAmount = withdrawAmount;
}

}


