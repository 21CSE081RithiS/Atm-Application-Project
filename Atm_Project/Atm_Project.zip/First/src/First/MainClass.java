package First;

import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
        AtmOperationInterf op = new AtmOperationImpl();
        int atmnumber = 12345;
        int atmpin = 123;
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to ATM Machine !!!");
        System.out.print("Enter Atm Number :");
        int atmNumber = sc.nextInt();
        System.out.print("Enter Atm pin :");
        int pin = sc.nextInt();

        if ((atmnumber == atmNumber) && (atmpin == pin)) {
            while (true) {
                System.out.println("1.view the Available Balance\n2.Withdraw Amount\n3.Deposit Money\n4.View MiniStatement\n5.Exit");
                System.out.println("Enter the choice :");
                int ch = sc.nextInt();
                switch (ch) {
                    case 1:
                        op.viewBalance();
                        break;
                    case 2:
                        System.out.println("Enter Amount to withdraw");
                        double withdraw = sc.nextDouble();
                        op.withdrawAmount(withdraw);
                        break;
                    case 3:
                        System.out.println("Enter Amount to deposit");
                        double depositAmount = sc.nextDouble();
                        op.depositeAmount(depositAmount);
                        break;
                    case 4:
                        op.viewMiniStatement();
                        break;
                    case 5:
                        System.out.println("Collect your ATM card.\nThank you for using ATM machine.");
                        sc.close();
                        return; // Exits the program
                    default:
                        System.out.println("Enter correct choice");
                }
                pressAnyKeyToContinue(); // Wait for user input after each operation
            }
        } else {
            System.out.println("Incorrect ATM pin or Number");
            sc.close();
            System.exit(0);
        }
    }

    private static void pressAnyKeyToContinue() {
        System.out.println("Press Enter key to continue...");
        try {
            System.in.read();
            System.in.read(); // Catch newline character if necessary
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
