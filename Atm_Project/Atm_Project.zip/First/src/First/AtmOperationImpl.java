package First;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class AtmOperationImpl implements AtmOperationInterf {
ATM atm = new ATM();
Map<Double,String> ministmt = new HashMap<>();
	@Override
	public void viewBalance() {
	System.out.println("Available Balance is : "+atm.getBalance());
		
	}

	@Override
	public void withdrawAmount(double withdrawAmount) {
		if(withdrawAmount%500==0) {
		if(withdrawAmount<=atm.getBalance())
		{
			ministmt.put(withdrawAmount, "Amount withdrawn");
		System.out.println(" Collect the cash"+withdrawAmount);
		atm.setBalance(atm.getBalance()-withdrawAmount);
		viewBalance();
		}
		else {
			System.out.println("insufficient Balance !!");
		}
		}
		else {
			System.out.println("Please Enter the Amount in multiple of 500");
		}
	}

	@Override
	public void depositeAmount(double depositAmount) {
		ministmt.put(depositAmount, "Amount deposited");
	System.out.println(depositAmount+" Deposited Successfully !!");
	atm.setBalance(atm.getBalance()+depositAmount); //this method add the deposit amount into balance
	viewBalance();
		
	}

	@Override
	public void viewMiniStatement() {
		
		for(Entry<Double, String> m:ministmt.entrySet()){
			System.out.println(m.getKey()+" "+m.getValue());
		}
	}
	

}
